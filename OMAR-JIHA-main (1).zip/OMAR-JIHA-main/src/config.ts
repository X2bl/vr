/**
 * Single configurable destination for the "Where's your argument?" workspace application.
 * Override at build/runtime with VITE_APP_URL in your environment, or edit the fallback below.
 */
const RAW_APP_URL =
  (import.meta.env.VITE_APP_URL as string | undefined) ||
  'http://127.0.0.1:7863/';

export const APP_URL = RAW_APP_URL.endsWith('/')
  ? RAW_APP_URL
  : `${RAW_APP_URL}/`;

export function getWorkspaceUrl(routeHash?: 'home' | 'library' | 'new' | 'room' | 'review'): string {
  if (!routeHash) {
    return `${APP_URL}#home`;
  }
  return `${APP_URL}#${routeHash}`;
}
