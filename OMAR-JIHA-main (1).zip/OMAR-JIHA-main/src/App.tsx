import { useEffect, useRef, useState } from 'react';
import { LoginModal } from './components/LoginModal';
import { Navbar } from './components/Navbar';
import { PearlCanvas, SceneInteractiveState } from './components/PearlCanvas';
import { PostScrollSections } from './components/PostScrollSections';
import { ScriptedExample } from './components/ScriptedExample';
import { ScrollStory } from './components/ScrollStory';
import { ExampleMode, SCRIPTED_TURNS } from './data/debateData';

export default function App() {
  const [exampleMode, setExampleMode] = useState<ExampleMode>('attack');
  const [highlightedTurnId, setHighlightedTurnId] = useState<number | null>(4);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);

  const storyProgressRef = useRef(0);
  const postProgressRef = useRef(0);
  const sceneStateRef = useRef<SceneInteractiveState>({
    activeMode: 'attack',
    activeTurnId: 4,
    activeSpeaker: 'B',
  });

  useEffect(() => {
    const matchedTurn = SCRIPTED_TURNS.find((t) => t.id === highlightedTurnId);
    sceneStateRef.current = {
      activeMode: exampleMode,
      activeTurnId: highlightedTurnId,
      activeSpeaker: matchedTurn ? matchedTurn.speaker : null,
    };
  }, [exampleMode, highlightedTurnId]);

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    const syncPreference = () => setReducedMotion(mediaQuery.matches);
    syncPreference();

    mediaQuery.addEventListener('change', syncPreference);
    return () => mediaQuery.removeEventListener('change', syncPreference);
  }, []);

  const handleJumpToExampleTurn = (
    turnId: number,
    mode?: ExampleMode,
  ) => {
    if (mode) {
      setExampleMode(mode);
    }
    setHighlightedTurnId(turnId);
    const exampleSection = document.getElementById('example');
    if (exampleSection) {
      exampleSection.scrollIntoView({
        behavior: reducedMotion ? 'auto' : 'smooth',
      });
    }
  };

  return (
    <div className="relative min-h-screen bg-[#F9F9FC] text-[#24232B]">
      {/* Persistent Global 3D Argument Prism & Dual Voice Waves */}
      <div
        className="pointer-events-none fixed inset-0 z-0 overflow-hidden"
        aria-hidden="true"
      >
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(56% 52% at 50% 48%, rgba(202, 178, 240, 0.56) 0%, rgba(238, 232, 249, 0.74) 48%, #F8F7FC 100%)',
          }}
        />
        <div
          className="animate-drift pointer-events-none absolute"
          style={{
            inset: '-10%',
            background:
              'radial-gradient(40% 30% at 20% 80%, rgba(255,255,255,0.48), transparent 70%), radial-gradient(35% 25% at 85% 30%, rgba(255,255,255,0.38), transparent 70%)',
          }}
        />
        <PearlCanvas
          storyProgressRef={storyProgressRef}
          postProgressRef={postProgressRef}
          sceneStateRef={sceneStateRef}
          reducedMotion={reducedMotion}
          className="h-full w-full"
        />
      </div>

      <Navbar onOpenLogin={() => setLoginOpen(true)} />
      <main className="relative z-10">
        <ScrollStory
          storyProgressRef={storyProgressRef}
          postProgressRef={postProgressRef}
          onJumpToExampleTurn={handleJumpToExampleTurn}
          reducedMotion={reducedMotion}
        />
        <PostScrollSections
          exampleSection={
            <ScriptedExample
              mode={exampleMode}
              onModeChange={setExampleMode}
              highlightedTurnId={highlightedTurnId}
              onSelectTurn={setHighlightedTurnId}
              reducedMotion={reducedMotion}
            />
          }
        />
      </main>
      <LoginModal open={loginOpen} onClose={() => setLoginOpen(false)} />
    </div>
  );
}
