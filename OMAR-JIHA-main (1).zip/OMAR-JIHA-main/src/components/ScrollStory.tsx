import { useEffect, useRef, useState } from 'react';
import { ExampleMode } from '../data/debateData';
import { getWorkspaceUrl } from '../config';

interface ScrollStoryProps {
  storyProgressRef: React.MutableRefObject<number>;
  postProgressRef: React.MutableRefObject<number>;
  onJumpToExampleTurn: (turnId: number, mode?: ExampleMode) => void;
  reducedMotion: boolean;
}

const VISION_LINES = [
  ['Raw', 'Talk', 'Moves', 'Fast.'],
  ['Arguments', 'Need'],
  ['a', 'Clear', 'Trail.'],
];

const ACCOUNTING_WORDS =
  'Our debate workspace turns spoken English turns into a source-linked argument map — spotting personal attacks, sustained drift, and uneven speaking share under human moderator control.'.split(
    ' ',
  );

const HOTSPOTS = [
  {
    id: 'hs-1',
    turnId: 1,
    mode: 'argument-trail' as ExampleMode,
    left: '14%',
    top: '57%',
    label: 'Claim · Turn 01',
    value: 'Uniforms reduce pressure',
  },
  {
    id: 'hs-2',
    turnId: 2,
    mode: 'argument-trail' as ExampleMode,
    left: '34%',
    top: '40%',
    label: 'Rebuttal · Turn 02',
    value: 'May challenge turn 01',
  },
  {
    id: 'hs-3',
    turnId: 4,
    mode: 'attack' as ExampleMode,
    left: '70%',
    top: '64%',
    label: 'Personal remark',
    value: 'Turn 04 · Review context',
  },
  {
    id: 'hs-4',
    turnId: 6,
    mode: 'drift' as ExampleMode,
    left: '82%',
    top: '44%',
    label: 'Topic drift',
    value: 'Turns 06–07 off-topic',
  },
];

const STATION_FEATURES = [
  { num: '01', text: 'Automatic A/B speaker attribution' },
  { num: '02', text: 'Possible personal-attack alerts' },
  { num: '03', text: 'Sustained topic-drift tracking' },
  { num: '04', text: 'Suggested argument trail & links' },
  { num: '05', text: 'Local SQLite & JSONL exports' },
];

const SPARKLINE_POINTS = '0,60 30,54 60,56 90,42 120,45 150,28 180,22 214,10';

function clamp01(v: number): number {
  return Math.max(0, Math.min(1, v));
}

function seg(p: number, a: number, b: number): number {
  return clamp01((p - a) / (b - a));
}

function easeCubic(t: number): number {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

export function ScrollStory({
  storyProgressRef,
  postProgressRef,
  onJumpToExampleTurn,
  reducedMotion,
}: ScrollStoryProps) {
  const storyRef = useRef<HTMLElement | null>(null);
  const pointerTargetRef = useRef({ x: 0, y: 0 });
  const pointerSmoothRef = useRef({ x: 0, y: 0 });
  const sparkRef = useRef<SVGPolylineElement | null>(null);
  const [sparkLen, setSparkLen] = useState(260);

  const l0Ref = useRef<HTMLDivElement | null>(null);
  const heroCopyRef = useRef<HTMLDivElement | null>(null);
  const l1Ref = useRef<HTMLDivElement | null>(null);
  const hudRef = useRef<HTMLDivElement | null>(null);
  const captionRef = useRef<HTMLDivElement | null>(null);
  const hintRef = useRef<HTMLDivElement | null>(null);
  const voiceBadgeARef = useRef<HTMLDivElement | null>(null);
  const voiceBadgeBRef = useRef<HTMLDivElement | null>(null);
  const fogRef = useRef<HTMLDivElement | null>(null);
  const l2Ref = useRef<HTMLDivElement | null>(null);
  const l2ChipRef = useRef<HTMLSpanElement | null>(null);
  const l2SubRef = useRef<HTMLParagraphElement | null>(null);
  const visionWordRefs = useRef<(HTMLSpanElement | null)[]>([]);
  const l3Ref = useRef<HTMLDivElement | null>(null);
  const acctWordRefs = useRef<(HTMLSpanElement | null)[]>([]);
  const hotspotRefs = useRef<(HTMLDivElement | null)[]>([]);
  const l4Ref = useRef<HTMLDivElement | null>(null);
  const credRef = useRef<HTMLDivElement | null>(null);
  const cardRef = useRef<HTMLDivElement | null>(null);
  const countRef = useRef<HTMLSpanElement | null>(null);
  const featRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const progBarRef = useRef<HTMLDivElement | null>(null);

  const [activeHotspot, setActiveHotspot] = useState<string | null>('hs-3');
  const [activeFeat, setActiveFeat] = useState<number>(0);

  useEffect(() => {
    if (sparkRef.current) {
      setSparkLen(sparkRef.current.getTotalLength());
    }
  }, []);

  useEffect(() => {
    const onPointerMove = (e: PointerEvent) => {
      pointerTargetRef.current.x = e.clientX / window.innerWidth - 0.5;
      pointerTargetRef.current.y = e.clientY / window.innerHeight - 0.5;
    };
    window.addEventListener('pointermove', onPointerMove, { passive: true });

    let sp = 0;
    let lastTime = performance.now();
    let rafId = 0;

    const tick = (now: number) => {
      const dt = Math.min(64, now - lastTime);
      lastTime = now;

      const story = storyRef.current;
      let rawP = 0;
      let rawPost = 0;
      if (story) {
        const rect = story.getBoundingClientRect();
        const scrollable = Math.max(1, story.offsetHeight - window.innerHeight);
        rawP = clamp01(-rect.top / scrollable);

        const pastStory = Math.max(0, -rect.top - scrollable);
        const totalPost = Math.max(
          1,
          document.documentElement.scrollHeight - window.innerHeight - scrollable,
        );
        rawPost = clamp01(pastStory / totalPost);
      }

      if (reducedMotion) {
        sp = rawP;
      } else {
        const alpha = 1 - Math.pow(0.86, dt / 16.7);
        sp += (rawP - sp) * alpha;
        if (Math.abs(rawP - sp) < 0.0002) sp = rawP;
      }

      storyProgressRef.current = sp;
      postProgressRef.current = rawPost;

      const pt = pointerTargetRef.current;
      const ps = pointerSmoothRef.current;
      ps.x += (pt.x - ps.x) * (reducedMotion ? 1 : 0.06);
      ps.y += (pt.y - ps.y) * (reducedMotion ? 1 : 0.06);
      const sx = reducedMotion ? 0 : ps.x;
      const sy = reducedMotion ? 0 : ps.y;

      if (progBarRef.current) {
        progBarRef.current.style.transform = `scaleX(${sp})`;
      }

      // Left/Right Voice Signal Badges fly gracefully outward on scroll
      const fp = seg(sp, 0.02, 0.16);
      if (voiceBadgeARef.current) {
        voiceBadgeARef.current.style.visibility = fp >= 1 ? 'hidden' : 'visible';
        voiceBadgeARef.current.style.transform = `translate3d(${(-fp * 18 + sx * -18).toFixed(2)}vw, ${(-fp * 10 + sy * -12).toFixed(2)}vh, 0)`;
        voiceBadgeARef.current.style.opacity = `${(1 - fp).toFixed(3)}`;
      }
      if (voiceBadgeBRef.current) {
        voiceBadgeBRef.current.style.visibility = fp >= 1 ? 'hidden' : 'visible';
        voiceBadgeBRef.current.style.transform = `translate3d(${(fp * 18 + sx * -18).toFixed(2)}vw, ${(fp * 10 + sy * -12).toFixed(2)}vh, 0)`;
        voiceBadgeBRef.current.style.opacity = `${(1 - fp).toFixed(3)}`;
      }

      // Beat 1 Hero Copy (L0 & L1)
      const h = seg(sp, 0.02, 0.12);
      if (l0Ref.current && heroCopyRef.current) {
        l0Ref.current.style.visibility = h >= 1 ? 'hidden' : 'visible';
        heroCopyRef.current.style.transform = `translate3d(${(-sx * 10).toFixed(2)}px, ${(-h * 80 - sy * 6).toFixed(2)}px, 0) scale(${(1 + h * 0.1).toFixed(3)})`;
        heroCopyRef.current.style.filter = `blur(${(h * 12).toFixed(2)}px)`;
        heroCopyRef.current.style.opacity = `${(1 - h).toFixed(3)}`;
      }

      if (l1Ref.current) {
        l1Ref.current.style.visibility = h >= 1 ? 'hidden' : 'visible';
      }
      if (hudRef.current) {
        hudRef.current.style.transform = `translate3d(${(sx * 20).toFixed(2)}px, ${(sy * 14 - h * 36).toFixed(2)}px, 0)`;
        hudRef.current.style.opacity = `${(1 - seg(sp, 0.02, 0.09)).toFixed(3)}`;
      }
      const capOp = `${(1 - seg(sp, 0.01, 0.06)).toFixed(3)}`;
      if (captionRef.current) captionRef.current.style.opacity = capOp;
      if (hintRef.current) hintRef.current.style.opacity = capOp;

      // Subtle atmospheric veil behind Beat 3 word-by-word copy
      const fgIn = easeCubic(seg(sp, 0.38, 0.47));
      const fgOut = seg(sp, 0.65, 0.74);
      const fgOp = fgIn * (1 - fgOut);
      if (fogRef.current) {
        fogRef.current.style.visibility = fgOp <= 0.005 ? 'hidden' : 'visible';
        fogRef.current.style.opacity = `${fgOp.toFixed(3)}`;
        fogRef.current.style.transform = `translate3d(${((fgIn - 1) * 16 + sx * -8).toFixed(2)}vw, ${(sy * -6).toFixed(2)}px, 0)`;
      }

      // Beat 2 Vision Resolve (L2)
      const vIn = seg(sp, 0.16, 0.27);
      const vOut = seg(sp, 0.34, 0.42);
      const vVis = vIn > 0 && vOut < 1;
      if (l2Ref.current) {
        l2Ref.current.style.visibility = vVis ? 'visible' : 'hidden';
      }
      if (vVis) {
        visionWordRefs.current.forEach((el, idx) => {
          if (!el) return;
          const k = clamp01(vIn * 1.65 - idx * 0.08);
          el.style.transform = `translate3d(0, ${((1 - k) * 28 - vOut * 55).toFixed(2)}px, 0)`;
          el.style.filter = `blur(${((1 - k) * 11 + vOut * 13).toFixed(2)}px)`;
          el.style.opacity = `${(k * (1 - vOut)).toFixed(3)}`;
        });
        const metaOp = clamp01(vIn * 2 - 0.6) * (1 - vOut);
        const metaY = -vOut * 48;
        if (l2ChipRef.current) {
          l2ChipRef.current.style.opacity = `${metaOp.toFixed(3)}`;
          l2ChipRef.current.style.transform = `translate3d(0, ${metaY.toFixed(1)}px, 0)`;
        }
        if (l2SubRef.current) {
          l2SubRef.current.style.opacity = `${metaOp.toFixed(3)}`;
          l2SubRef.current.style.transform = `translate3d(0, ${metaY.toFixed(1)}px, 0)`;
        }
      }

      // Beat 3 Constellation Accounting + 4 Hotspots (L3)
      const aIn = seg(sp, 0.45, 0.55);
      const aOut = seg(sp, 0.63, 0.69);
      const aVis = aIn > 0 && aOut < 1;
      if (l3Ref.current) {
        l3Ref.current.style.visibility = aVis ? 'visible' : 'hidden';
      }
      if (aVis) {
        const count = ACCOUNTING_WORDS.length;
        acctWordRefs.current.forEach((el, i) => {
          if (!el) return;
          const k = clamp01(aIn * 2.2 - (i / count) * 1.2);
          el.style.opacity = `${((0.15 + 0.85 * k) * (1 - aOut)).toFixed(3)}`;
          el.style.filter = `blur(${((1 - k) * 5 + aOut * 9).toFixed(2)}px)`;
        });

        hotspotRefs.current.forEach((el, i) => {
          if (!el) return;
          const k = seg(sp, 0.48 + i * 0.02, 0.52 + i * 0.02);
          const sc = k * (1 - aOut);
          el.style.visibility = sc <= 0.01 ? 'hidden' : 'visible';
          el.style.transform = `translate3d(${(sx * -22).toFixed(2)}px, ${(sy * -16).toFixed(2)}px, 0) scale(${sc.toFixed(3)})`;
        });
      }

      // Beat 4 Moderator Station: Tilting Glass Card + Sparkline + 5-Row Switcher (L4)
      const sIn = seg(sp, 0.71, 0.82);
      const l4Vis = sIn > 0;
      if (l4Ref.current) {
        l4Ref.current.style.visibility = l4Vis ? 'visible' : 'hidden';
      }
      if (l4Vis) {
        if (credRef.current) {
          credRef.current.style.opacity = `${sIn.toFixed(3)}`;
          credRef.current.style.transform = `translate3d(0, ${((1 - sIn) * 30).toFixed(2)}px, 0)`;
          credRef.current.style.filter = `blur(${((1 - sIn) * 8).toFixed(2)}px)`;
        }

        const cIn = easeCubic(seg(sp, 0.74, 0.86));
        if (cardRef.current) {
          cardRef.current.style.opacity = `${cIn.toFixed(3)}`;
          cardRef.current.style.transform = `perspective(900px) translate3d(${(sx * -14).toFixed(2)}px, ${((1 - cIn) * 60 + sy * -10).toFixed(2)}px, 0) rotateY(${(sx * 8).toFixed(2)}deg) rotateX(${(-sy * 8).toFixed(2)}deg)`;
        }

        if (countRef.current) {
          const val = Math.round(58 * seg(sp, 0.76, 0.9));
          countRef.current.textContent = String(val);
        }

        if (sparkRef.current) {
          const drawT = seg(sp, 0.77, 0.92);
          sparkRef.current.style.strokeDasharray = `${sparkLen}`;
          sparkRef.current.style.strokeDashoffset = `${(sparkLen * (1 - drawT)).toFixed(2)}`;
        }

        featRefs.current.forEach((el, i) => {
          if (!el) return;
          const k = easeCubic(seg(sp, 0.76 + i * 0.024, 0.82 + i * 0.024));
          el.style.opacity = `${k.toFixed(3)}`;
          el.style.transform = `translateX(${((1 - k) * 40).toFixed(2)}px)`;
        });
      }

      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('pointermove', onPointerMove);
    };
  }, [reducedMotion, sparkLen, storyProgressRef, postProgressRef]);

  let visionWordIdx = 0;

  return (
    <section
      id="top"
      ref={storyRef}
      aria-label="Interactive Argument Resonance Story"
      className="relative h-[480vh] bg-transparent"
    >
      <div className="sticky top-0 h-screen overflow-hidden bg-transparent">
        {/* Subtle left atmospheric cushion behind Beat 3 paragraph */}
        <div
          ref={fogRef}
          className="pointer-events-none absolute"
          style={{
            left: '-8vw',
            top: '-6vh',
            width: '56vw',
            height: '62vh',
            visibility: 'hidden',
            WebkitMaskImage:
              'radial-gradient(ellipse 52% 48% at 46% 46%, #000 44%, rgba(0,0,0,.7) 64%, transparent 100%)',
            maskImage:
              'radial-gradient(ellipse 52% 48% at 46% 46%, #000 44%, rgba(0,0,0,.7) 64%, transparent 100%)',
          }}
          aria-hidden="true"
        >
          <div
            className="absolute inset-0 blur-[12px]"
            style={{
              background:
                'radial-gradient(60% 55% at 40% 45%, rgba(249,249,252,0.92), rgba(244,241,249,0.84) 60%, rgba(237,231,247,0.68))',
            }}
          />
        </div>

        {/* ============================================================== */}
        {/* LAYER L0 — HERO MONUMENTAL HEADLINE                            */}
        {/* ============================================================== */}
        <div
          ref={l0Ref}
          className="pointer-events-none absolute inset-0 z-10"
        >
          <div
            ref={heroCopyRef}
            className="pointer-events-auto absolute left-0 right-0 top-[11.5vh] px-4 text-center sm:top-[11vh]"
          >
            <span className="chip-lavender">Human-led debate intelligence · English</span>
            <h1 className="mx-auto mt-3.5 max-w-4xl text-[clamp(36px,5.6vw,84px)] font-medium leading-[0.95] tracking-[-0.045em] text-[#24232B]">
              <span className="block overflow-hidden pb-[0.06em]">
                <span className="animate-rise inline-block">
                  Every Voice. Every Argument.
                </span>
              </span>
            </h1>
          </div>
        </div>

        {/* ============================================================== */}
        {/* LEFT & RIGHT KINETIC VOICE PRESENCE CARDS (Synced with Waves)  */}
        {/* ============================================================== */}
        <div
          ref={voiceBadgeARef}
          className="pointer-events-none absolute left-[4%] top-[44%] z-20 hidden rounded-[12px] border border-[#CBB7E8]/80 bg-white/76 px-3.5 py-2.5 shadow-[0_12px_30px_rgba(143,106,197,0.14)] lg:block"
          aria-hidden="true"
        >
          <div className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full bg-[#8F6AC5]" />
            <span className="font-mono-data text-[10.5px] font-medium uppercase tracking-[0.14em] text-[#24232B]">
              Voice A · Claiming
            </span>
          </div>
          <div className="mt-1.5 flex items-end gap-1">
            <span className="h-2 w-1 rounded-full bg-[#A58AC7]/60" />
            <span className="h-3.5 w-1 rounded-full bg-[#8F6AC5]" />
            <span className="h-2.5 w-1 rounded-full bg-[#A58AC7]/80" />
            <span className="h-4 w-1 rounded-full bg-[#8F6AC5]" />
            <span className="h-2 w-1 rounded-full bg-[#A58AC7]/70" />
            <span className="font-mono-data ml-1.5 text-[10px] text-[#5C5866]">
              Turn 01 · Source linked
            </span>
          </div>
        </div>

        <div
          ref={voiceBadgeBRef}
          className="pointer-events-none absolute right-[4%] top-[44%] z-20 hidden rounded-[12px] border border-[#EBD2BD]/90 bg-white/76 px-3.5 py-2.5 shadow-[0_12px_30px_rgba(216,155,112,0.14)] lg:block"
          aria-hidden="true"
        >
          <div className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full bg-[#E2A57A]" />
            <span className="font-mono-data text-[10.5px] font-medium uppercase tracking-[0.14em] text-[#24232B]">
              Voice B · Rebutting
            </span>
          </div>
          <div className="mt-1.5 flex items-end gap-1">
            <span className="h-2.5 w-1 rounded-full bg-[#E8BC9C]/70" />
            <span className="h-4 w-1 rounded-full bg-[#E2A57A]" />
            <span className="h-2 w-1 rounded-full bg-[#E8BC9C]" />
            <span className="h-3 w-1 rounded-full bg-[#E2A57A]" />
            <span className="h-2.5 w-1 rounded-full bg-[#E8BC9C]/70" />
            <span className="font-mono-data ml-1.5 text-[10px] text-[#5C5866]">
              Turn 02 · Challenges T01
            </span>
          </div>
        </div>

        {/* ============================================================== */}
        {/* LAYER L1 — ARCHITECTURAL HUD, EDITORIAL MANIFEST & ACTIONS     */}
        {/* ============================================================== */}
        <div
          ref={l1Ref}
          className="pointer-events-none absolute inset-0 z-20"
        >
          {/* Precision Astrolabe HUD */}
          <div
            ref={hudRef}
            className="pointer-events-none absolute left-[53%] top-[61%] hidden sm:block"
          >
            <div className="relative">
              <div
                className="absolute -left-11 top-1 h-[22px] w-[22px]"
                aria-hidden="true"
              >
                <span className="absolute left-0 top-[10.5px] h-px w-full bg-[#8F6AC5]/75" />
                <span className="absolute left-[10.5px] top-0 h-full w-px bg-[#8F6AC5]/75" />
              </div>

              <div className="relative rounded-md bg-white/55 px-2.5 py-1.5">
                <div
                  className="hud-brackets pointer-events-none absolute border border-[#8F6AC5]/55"
                  style={{ inset: '-8px -14px -10px -8px' }}
                  aria-hidden="true"
                />
                <span className="chip-lavender">Argument prism</span>
                <pre className="font-mono-data mt-2 text-[11px] leading-[1.6] tracking-[0.12em] text-[#24232B]">
{`VOICES   A ↔ B SHARED MIC
SIGNALS  ATTACK · DRIFT · TRAIL
CONTROL  MODERATOR-LED`}
                </pre>
              </div>
            </div>
          </div>

          {/* Bottom-Left Editorial Manifest + Primary Actions */}
          <div
            ref={captionRef}
            className="pointer-events-auto absolute bottom-[68px] left-[18px] right-[18px] max-w-md sm:bottom-[34px] sm:left-[34px] sm:right-auto"
          >
            <div className="border-l-2 border-[#8F6AC5] pl-4">
              <p className="font-mono-data text-[11.5px] uppercase leading-[1.7] tracking-[0.12em] text-[#4B4759]">
                Follow two voices in real time.
                <br />
                Spot drift and personal remarks,
                <br />
                trace every claim back to its turn.
              </p>
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-2.5">
              <a
                href={getWorkspaceUrl('home')}
                className="btn-primary inline-flex min-h-[40px] items-center gap-2 whitespace-nowrap rounded-[9px] px-4 py-2 text-xs font-medium"
              >
                <span>Open workspace</span>
                <span aria-hidden="true">→</span>
              </a>
              <a
                href="#example"
                className="btn-secondary inline-flex min-h-[40px] items-center whitespace-nowrap rounded-[9px] px-4 py-2 text-xs font-medium"
              >
                Try interactive debate
              </a>
            </div>
          </div>

          {/* Bottom-Right Scroll Hint */}
          <div
            ref={hintRef}
            className="pointer-events-none absolute bottom-[24px] right-[18px] flex items-center gap-2.5 sm:bottom-[36px] sm:right-[34px]"
          >
            <span className="font-mono-data text-[11px] uppercase tracking-[0.16em] text-[#4B4759]">
              Scroll into the debate
            </span>
            <span className="flex h-5 w-5 items-center justify-center rounded-full border border-[#8F6AC5]/60 text-[#24232B]">
              <span className="animate-nudge text-[11px] leading-none">⌄</span>
            </span>
          </div>
        </div>

        {/* ============================================================== */}
        {/* LAYER L2 — VISION STATEMENT RESOLVING MID-FLIGHT               */}
        {/* ============================================================== */}
        <div
          ref={l2Ref}
          className="pointer-events-none absolute inset-0 z-20"
          style={{ visibility: 'hidden' }}
        >
          <div className="absolute left-1/2 top-1/2 w-[min(840px,90vw)] -translate-x-1/2 -translate-y-1/2 text-center">
            <span ref={l2ChipRef} className="chip-lavender">
              From noise to structure
            </span>
            <h2 className="my-5 text-[clamp(34px,4.8vw,70px)] font-medium leading-[1.02] tracking-[-0.04em] text-[#24232B]">
              {VISION_LINES.map((line, lIdx) => (
                <span key={lIdx} className="block">
                  {line.map((word) => {
                    const idx = visionWordIdx++;
                    return (
                      <span
                        key={`${word}-${idx}`}
                        ref={(el) => {
                          visionWordRefs.current[idx] = el;
                        }}
                        className="mr-[0.22em] inline-block"
                      >
                        {word}
                      </span>
                    );
                  })}
                </span>
              ))}
            </h2>
            <p
              ref={l2SubRef}
              className="mx-auto max-w-md text-base leading-[1.5] text-[#4B4759]"
            >
              Not an automated judge — a calm workspace that illuminates what
              each speaker said and how ideas collide.
            </p>
          </div>
        </div>

        {/* ============================================================== */}
        {/* LAYER L3 — WORD-BY-WORD ACCOUNTING & 4 CONSTELLATION SIGNALS   */}
        {/* ============================================================== */}
        <div
          ref={l3Ref}
          className="pointer-events-none absolute inset-0 z-20"
          style={{ visibility: 'hidden' }}
        >
          <p
            className="pointer-events-none absolute left-[18px] top-[14vh] w-[min(560px,88vw)] text-[clamp(20px,1.95vw,29px)] font-normal leading-[1.18] tracking-[-0.02em] text-[#24232B] sm:left-[34px]"
            style={{ textShadow: '0 0 24px rgba(255,255,255,0.88)' }}
          >
            {ACCOUNTING_WORDS.map((word, i) => (
              <span
                key={`${word}-${i}`}
                ref={(el) => {
                  acctWordRefs.current[i] = el;
                }}
                className="mr-[0.24em] inline-block"
              >
                {word}
              </span>
            ))}
          </p>

          {HOTSPOTS.map((hs, i) => {
            const isOn = activeHotspot === hs.id;
            return (
              <div
                key={hs.id}
                ref={(el) => {
                  hotspotRefs.current[i] = el;
                }}
                style={{ left: hs.left, top: hs.top }}
                className="pointer-events-auto absolute -translate-x-1/2 -translate-y-1/2"
              >
                <div className="group flex flex-col items-start gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      setActiveHotspot((prev) => (prev === hs.id ? null : hs.id))
                    }
                    className="hotspot-ring relative flex h-[24px] w-[24px] items-center justify-center rounded-full bg-[#8F6AC5] text-white transition-transform duration-200 hover:scale-110"
                    aria-expanded={isOn}
                    aria-label={`${hs.label}: ${hs.value}`}
                  >
                    <span className="h-[1.5px] w-[10px] bg-white" />
                    <span
                      className={`absolute h-[10px] w-[1.5px] bg-white transition-transform duration-200 ${
                        isOn ? 'scale-y-0' : 'scale-y-100'
                      }`}
                    />
                  </button>

                  <div className="rounded-[6px] border border-[#DCD2EE] bg-white/90 px-2.5 py-1.5 shadow-[0_6px_18px_rgba(36,35,43,0.08)]">
                    <div className="font-mono-data text-[10.5px] uppercase tracking-[0.14em] text-[#24232B]">
                      {hs.label}
                    </div>
                    <div
                      className={`overflow-hidden transition-all duration-300 ${
                        isOn
                          ? 'mt-1 max-h-14 opacity-100'
                          : 'max-h-0 opacity-0 group-hover:mt-1 group-hover:max-h-14 group-hover:opacity-100'
                      }`}
                    >
                      <div className="text-xs font-medium text-[#634496]">
                        {hs.value}
                      </div>
                      <button
                        type="button"
                        onClick={() => onJumpToExampleTurn(hs.turnId, hs.mode)}
                        className="font-mono-data mt-0.5 text-[10px] uppercase tracking-[0.12em] text-[#24232B] underline decoration-[#8F6AC5]/50 underline-offset-2 hover:text-[#8F6AC5]"
                      >
                        Inspect Turn 0{hs.turnId} →
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* ============================================================== */}
        {/* LAYER L4 — MODERATOR COCKPIT: PARTICIPATION CARD + 5 PILLARS   */}
        {/* ============================================================== */}
        <div
          ref={l4Ref}
          className="pointer-events-none absolute inset-0 z-20"
          style={{ visibility: 'hidden' }}
        >
          <div
            ref={credRef}
            className="pointer-events-none absolute left-[18px] top-[12vh] max-w-[380px] sm:left-[34px] sm:top-[13vh]"
          >
            <span className="chip-lavender mb-3">✕ Moderator station</span>
            <h2
              className="text-[clamp(22px,2.1vw,31px)] font-medium leading-[1.1] tracking-[-0.025em] text-[#24232B]"
              style={{ textShadow: '0 0 24px rgba(255,255,255,0.85)' }}
            >
              Human judgment backed by clear source links
            </h2>
          </div>

          <div
            ref={cardRef}
            className="pearl-card-surface pointer-events-auto absolute bottom-[7vh] left-[18px] w-[225px] rounded-[14px] p-4 sm:bottom-auto sm:left-[36%] sm:top-[37vh] sm:w-[258px] sm:p-[18px]"
          >
            <h3 className="text-[15px] font-medium leading-tight text-[#24232B]">
              Speaker A speaking
              <br />
              participation share
            </h3>
            <p className="font-mono-data mt-1 text-[9.5px] uppercase tracking-[0.12em] text-[#686472]">
              Illustrative · Turn 01–07
            </p>

            <div className="mt-3 flex items-baseline gap-1.5">
              <span
                ref={countRef}
                className="font-mono-data text-[44px] font-medium leading-none tracking-[-0.04em] text-[#24232B]"
              >
                0
              </span>
              <span className="font-mono-data text-[11px] text-[#686472]">
                % share
              </span>
            </div>

            <span className="chip-lavender absolute right-4 top-[96px]">
              B: 42% (1:08)
            </span>

            <svg
              viewBox="0 0 220 70"
              className="mt-4 h-[64px] w-full overflow-visible"
              aria-hidden="true"
            >
              <polyline
                ref={sparkRef}
                fill="none"
                stroke="#8F6AC5"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
                points={SPARKLINE_POINTS}
              />
              <circle cx="90" cy="42" r="2.6" fill="#24232B" />
              <circle cx="150" cy="28" r="2.6" fill="#24232B" />
              <circle cx="214" cy="10" r="3.6" fill="#8F6AC5" />
            </svg>

            <div className="font-mono-data mt-1 flex justify-between text-[9.5px] uppercase tracking-[0.14em] text-[#686472]">
              <span>T1</span>
              <span>T3</span>
              <span>T5</span>
              <span>T7</span>
            </div>
          </div>

          <div className="pearl-card-surface pointer-events-auto absolute bottom-[7vh] right-[18px] w-[46vw] max-w-[400px] rounded-[14px] px-3.5 py-1.5 sm:bottom-auto sm:right-[34px] sm:top-[30vh] sm:w-[min(400px,36vw)] sm:px-4">
            {STATION_FEATURES.map((feat, idx) => {
              const isOn = activeFeat === idx;
              return (
                <button
                  key={feat.num}
                  ref={(el) => {
                    featRefs.current[idx] = el;
                  }}
                  type="button"
                  onClick={() => setActiveFeat(idx)}
                  className={`grid w-full grid-cols-[28px_1fr_16px] items-center gap-2 py-2.5 text-left transition-all duration-200 ${
                    idx < STATION_FEATURES.length - 1
                      ? 'border-b border-[#EEECF2]'
                      : ''
                  } ${
                    isOn
                      ? 'pl-1.5 text-[#634496]'
                      : 'text-[#24232B] hover:pl-1.5 hover:text-[#634496]'
                  }`}
                >
                  <span className="font-mono-data text-[10.5px] opacity-60">
                    {feat.num}
                  </span>
                  <span className="font-mono-data text-[10px] uppercase tracking-[0.11em] sm:text-[11px]">
                    {feat.text}
                  </span>
                  <span
                    className={`hidden text-xs transition-transform duration-200 sm:inline-block ${
                      isOn ? 'translate-x-1' : ''
                    }`}
                    aria-hidden="true"
                  >
                    →
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom Progress Hairline */}
        <div
          className="pointer-events-none absolute bottom-[18px] left-1/2 z-30 h-[2px] w-[120px] -translate-x-1/2 overflow-hidden rounded-full bg-[#24232B]/15"
          aria-hidden="true"
        >
          <div
            ref={progBarRef}
            className="h-full w-full origin-left bg-[#8F6AC5]"
            style={{ transform: 'scaleX(0)' }}
          />
        </div>
      </div>
    </section>
  );
}
