import { useEffect, useRef, useState, type FormEvent } from 'react';
import { ArrowRight, CheckCircle2, Eye, EyeOff, Lock, Mail, X } from 'lucide-react';
import { getWorkspaceUrl } from '../config';

interface LoginModalProps {
  open: boolean;
  onClose: () => void;
}

export function LoginModal({ open, onClose }: LoginModalProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [error, setError] = useState('');
  const [statusMessage, setStatusMessage] = useState<'none' | 'submitted' | 'forgot' | 'sso'>('none');

  const emailInputRef = useRef<HTMLInputElement | null>(null);
  const workspaceUrl = getWorkspaceUrl('home');

  useEffect(() => {
    if (!open) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    const timer = window.setTimeout(() => {
      emailInputRef.current?.focus();
    }, 30);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.clearTimeout(timer);
    };
  }, [open, onClose]);

  if (!open) return null;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmedEmail = email.trim();
    if (!trimmedEmail || !trimmedEmail.includes('@')) {
      setError('Please enter a valid email address.');
      return;
    }
    if (password.length < 4) {
      setError('Please enter your password (at least 4 characters).');
      return;
    }
    setError('');
    setStatusMessage('submitted');
  };

  const resetPreview = () => {
    setStatusMessage('none');
    setError('');
    setPassword('');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#24232B]/30 p-4"
      role="presentation"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="login-modal-title"
        className="relative w-full max-w-[430px] rounded-[20px] border border-[#DCD2EE] bg-white p-6 shadow-[0_28px_72px_rgba(64,51,79,0.18)] sm:p-7"
      >
        {/* Top bar: Pearlescent identity + Close button */}
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <span
              className="pearl-mini inline-block h-6 w-6 shrink-0 rounded-full"
              aria-hidden="true"
            />
            <span className="chip-lavender">Moderator access · UI preview</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close log in dialog"
            className="inline-flex h-10 w-10 items-center justify-center rounded-[10px] border border-[#EEECF2] bg-[#FCFCFE] text-[#686472] transition-colors hover:border-[#D4CCE4] hover:text-[#24232B]"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        <h2
          id="login-modal-title"
          className="mt-5 text-2xl font-medium tracking-[-0.025em] text-[#24232B]"
        >
          Log in to your workspace
        </h2>
        <p className="mt-1.5 text-sm leading-relaxed text-[#5C5866]">
          Access saved debate sessions, speaker notes, and local moderation
          exports.
        </p>

        {statusMessage === 'submitted' ? (
          <div className="mt-6 rounded-[14px] border border-[#CBB7E8] bg-[#F3EDFB]/55 p-5">
            <div className="flex items-start gap-3">
              <CheckCircle2
                className="mt-0.5 h-5 w-5 shrink-0 text-[#634496]"
                aria-hidden="true"
              />
              <div>
                <p className="text-sm font-semibold text-[#24232B]">
                  Sign-in interface preview ready
                </p>
                <p className="mt-1 text-xs leading-relaxed text-[#464252]">
                  Signed in visually as{' '}
                  <span className="font-mono-data font-medium text-[#24232B]">
                    {email.trim()}
                  </span>
                  . No backend session or external credential check runs in this
                  UI-only preview.
                </p>
              </div>
            </div>

            <div className="mt-4 flex flex-wrap items-center gap-2.5">
              <a
                href={workspaceUrl}
                className="btn-primary inline-flex min-h-[40px] items-center gap-1.5 rounded-[10px] px-4 py-2 text-xs font-medium"
              >
                <span>Open workspace</span>
                <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
              </a>
              <button
                type="button"
                onClick={resetPreview}
                className="btn-secondary inline-flex min-h-[40px] items-center rounded-[10px] px-3.5 py-2 text-xs font-medium"
              >
                Use another account
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-5 space-y-4" noValidate>
            {error && (
              <div
                role="alert"
                className="rounded-[10px] border border-[#F3D2DE] bg-[#FDF2F6] px-3.5 py-2.5 text-xs font-medium text-[#B5456C]"
              >
                {error}
              </div>
            )}

            {statusMessage === 'forgot' && (
              <div className="rounded-[10px] border border-[#DCD2EE] bg-[#F3EDFB]/50 px-3.5 py-2.5 text-xs leading-relaxed text-[#464252]">
                Password recovery is disabled in this UI-only preview. In the
                local workspace, sessions are stored directly on your machine.
              </div>
            )}

            {statusMessage === 'sso' && (
              <div className="rounded-[10px] border border-[#DCD2EE] bg-[#F3EDFB]/50 px-3.5 py-2.5 text-xs leading-relaxed text-[#464252]">
                Institutional SSO is shown for layout preview only and is not
                connected to an identity provider yet.
              </div>
            )}

            <div>
              <label
                htmlFor="login-email"
                className="block text-xs font-medium text-[#24232B]"
              >
                Email address
              </label>
              <div className="relative mt-1.5">
                <Mail
                  className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#85818F]"
                  aria-hidden="true"
                />
                <input
                  ref={emailInputRef}
                  id="login-email"
                  type="email"
                  autoComplete="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (error) setError('');
                  }}
                  placeholder="moderator@university.edu"
                  className="min-h-[44px] w-full rounded-[11px] border border-[#E4E0EC] bg-[#FCFCFE] pl-10 pr-3.5 text-sm text-[#24232B] placeholder:text-[#85818F] focus:border-[#8F6AC5] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#8F6AC5]/20"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between">
                <label
                  htmlFor="login-password"
                  className="block text-xs font-medium text-[#24232B]"
                >
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => setStatusMessage('forgot')}
                  className="text-xs font-medium text-[#8F6AC5] hover:text-[#634496]"
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative mt-1.5">
                <Lock
                  className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#85818F]"
                  aria-hidden="true"
                />
                <input
                  id="login-password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (error) setError('');
                  }}
                  placeholder="••••••••"
                  className="min-h-[44px] w-full rounded-[11px] border border-[#E4E0EC] bg-[#FCFCFE] pl-10 pr-11 text-sm text-[#24232B] placeholder:text-[#85818F] focus:border-[#8F6AC5] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#8F6AC5]/20"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute right-1.5 top-1/2 inline-flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-lg text-[#686472] hover:bg-[#F3EDFB] hover:text-[#24232B]"
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" aria-hidden="true" />
                  ) : (
                    <Eye className="h-4 w-4" aria-hidden="true" />
                  )}
                </button>
              </div>
            </div>

            <label className="flex cursor-pointer items-center gap-2.5 text-xs text-[#5C5866]">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="h-4 w-4 rounded border-[#D4CCE4] accent-[#8F6AC5]"
              />
              <span>Keep this browser signed in</span>
            </label>

            <button
              type="submit"
              className="btn-primary flex min-h-[44px] w-full items-center justify-center gap-2 rounded-[11px] px-4 py-2.5 text-sm font-medium"
            >
              <span>Log in</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>

            <div className="relative py-1">
              <div className="absolute inset-0 flex items-center" aria-hidden="true">
                <div className="w-full border-t border-[#EEECF2]" />
              </div>
              <div className="relative flex justify-center">
                <span className="font-mono-data bg-white px-2.5 text-[10px] uppercase tracking-[0.14em] text-[#85818F]">
                  Or continue with
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setStatusMessage('sso')}
              className="btn-secondary flex min-h-[42px] w-full items-center justify-center gap-2 rounded-[11px] px-4 py-2 text-xs font-medium"
            >
              <span
                className="h-2 w-2 rounded-full bg-[#8F6AC5]"
                aria-hidden="true"
              />
              <span>Continue with Academic SSO</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
