import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { ExampleMode, SpeakerId } from '../data/debateData';

export interface SceneInteractiveState {
  activeMode: ExampleMode;
  activeTurnId: number | null;
  activeSpeaker: SpeakerId | null;
}

interface PearlCanvasProps {
  storyProgressRef: React.MutableRefObject<number>;
  postProgressRef: React.MutableRefObject<number>;
  sceneStateRef: React.MutableRefObject<SceneInteractiveState>;
  reducedMotion: boolean;
  className?: string;
}

const _targetCamPos = new THREE.Vector3();
const _targetGroupPos = new THREE.Vector3();
const _lookTarget = new THREE.Vector3();
const _dummy = new THREE.Object3D();
const _tmpColor = new THREE.Color();

function detectSoftwareWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) ?? '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

function hasWebGLSupport(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return false;
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return true;
  } catch {
    return false;
  }
}

function seg(p: number, a: number, b: number): number {
  return Math.max(0, Math.min(1, (p - a) / (b - a)));
}

function easeCubic(t: number): number {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

/**
 * Swirling mother-of-pearl / nacre interference texture.
 */
function createPearlNacreTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const base = ctx.createLinearGradient(0, 0, 1024, 512);
    base.addColorStop(0, '#fcfaff');
    base.addColorStop(0.22, '#dac6f7');
    base.addColorStop(0.45, '#b694e6');
    base.addColorStop(0.68, '#f4b5d3');
    base.addColorStop(0.86, '#e2d2f6');
    base.addColorStop(1, '#fcfaff');
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, 1024, 512);

    for (let i = 0; i < 16; i++) {
      const y = (i / 16) * 512;
      const grad = ctx.createLinearGradient(0, y, 1024, y + 80);
      if (i % 3 === 0) {
        grad.addColorStop(0, 'rgba(255, 255, 255, 0.68)');
        grad.addColorStop(0.5, 'rgba(138, 98, 200, 0.42)');
        grad.addColorStop(1, 'rgba(255, 255, 255, 0.52)');
      } else if (i % 3 === 1) {
        grad.addColorStop(0, 'rgba(244, 168, 206, 0.48)');
        grad.addColorStop(0.5, 'rgba(255, 255, 255, 0.68)');
        grad.addColorStop(1, 'rgba(232, 182, 146, 0.44)');
      } else {
        grad.addColorStop(0, 'rgba(195, 210, 244, 0.44)');
        grad.addColorStop(0.5, 'rgba(164, 124, 222, 0.44)');
        grad.addColorStop(1, 'rgba(255, 255, 255, 0.55)');
      }
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.bezierCurveTo(320, y - 48, 700, y + 68, 1024, y);
      ctx.lineTo(1024, y + 64);
      ctx.bezierCurveTo(700, y + 124, 320, y + 12, 0, y + 64);
      ctx.closePath();
      ctx.fill();
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  return tex;
}

function createPearlRoughnessTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#242424';
    ctx.fillRect(0, 0, 512, 256);
    for (let i = 0; i < 18; i++) {
      const x = (i * 53) % 512;
      const y = (i * 37) % 256;
      const g = ctx.createRadialGradient(x, y, 4, x, y, 90);
      g.addColorStop(0, 'rgba(68, 68, 68, 0.42)');
      g.addColorStop(1, 'rgba(36, 36, 36, 0)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 512, 256);
    }
  }
  return new THREE.CanvasTexture(canvas);
}

function createSoftGlowTexture(
  rgbaCenter: string,
  rgbaMid: string,
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const grad = ctx.createRadialGradient(128, 128, 6, 128, 128, 124);
    grad.addColorStop(0, rgbaCenter);
    grad.addColorStop(0.45, rgbaMid);
    grad.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 256, 256);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Dynamic 3D tapered ribbon strip geometry for kinetic acoustic voice waves.
 */
interface WaveRibbonInstance {
  mesh: THREE.Mesh;
  geo: THREE.BufferGeometry;
  mat: THREE.MeshPhysicalMaterial;
  side: -1 | 1;
  strandIndex: number;
  baseY: number;
  baseZ: number;
  freq: number;
  phaseOffset: number;
}

const WAVE_SEGMENTS = 76;

function createWaveRibbon(
  side: -1 | 1,
  strandIndex: number,
  colorHex: number,
  sheenHex: number,
): WaveRibbonInstance {
  const geo = new THREE.BufferGeometry();
  const vertCount = (WAVE_SEGMENTS + 1) * 2;
  const positions = new Float32Array(vertCount * 3);
  const normals = new Float32Array(vertCount * 3);
  const uvs = new Float32Array(vertCount * 2);
  const indices: number[] = [];

  for (let i = 0; i <= WAVE_SEGMENTS; i++) {
    const u = i / WAVE_SEGMENTS;
    uvs[i * 4] = u;
    uvs[i * 4 + 1] = 0;
    uvs[i * 4 + 2] = u;
    uvs[i * 4 + 3] = 1;
    // Default normal facing +Z
    normals[i * 6 + 2] = 1;
    normals[i * 6 + 5] = 1;
  }

  for (let i = 0; i < WAVE_SEGMENTS; i++) {
    const a = i * 2;
    const b = a + 1;
    const c = a + 2;
    const d = a + 3;
    indices.push(a, c, b);
    indices.push(b, c, d);
  }

  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('normal', new THREE.BufferAttribute(normals, 3));
  geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  geo.setIndex(indices);

  const mat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(colorHex),
    roughness: 0.16,
    metalness: 0.18,
    clearcoat: 1.0,
    clearcoatRoughness: 0.08,
    iridescence: 0.95,
    iridescenceIOR: 1.4,
    sheen: 0.9,
    sheenColor: new THREE.Color(sheenHex),
    transparent: true,
    opacity: strandIndex === 1 ? 0.88 : 0.62,
    side: THREE.DoubleSide,
    depthWrite: false,
  });

  const mesh = new THREE.Mesh(geo, mat);
  mesh.frustumCulled = false;

  return {
    mesh,
    geo,
    mat,
    side,
    strandIndex,
    baseY: (strandIndex - 1) * 0.34,
    baseZ: (strandIndex - 1) * -0.26,
    freq: 3.1 + strandIndex * 0.85,
    phaseOffset: strandIndex * 1.45,
  };
}

function updateWaveRibbon(
  ribbon: WaveRibbonInstance,
  elapsed: number,
  ampBoost: number,
  spanScale: number,
  scrollTwist: number,
) {
  const posAttr = ribbon.geo.getAttribute('position') as THREE.BufferAttribute;
  const normAttr = ribbon.geo.getAttribute('normal') as THREE.BufferAttribute;

  const startX = ribbon.side * (1.28 * spanScale);
  const endX = ribbon.side * (4.15 * spanScale);

  for (let i = 0; i <= WAVE_SEGMENTS; i++) {
    const t = i / WAVE_SEGMENTS;
    // Smooth tapered ribbon width (thickest mid-span, sharp tips)
    const envelope = Math.sin(t * Math.PI);
    const halfWidth = (0.045 + 0.075 * envelope) * (ribbon.strandIndex === 1 ? 1.15 : 0.85);

    const x = THREE.MathUtils.lerp(startX, endX, t);

    // Living harmonic wave converging into the central Pearl
    const wavePhase =
      t * ribbon.freq * Math.PI -
      elapsed * (2.1 + ribbon.strandIndex * 0.35) +
      ribbon.phaseOffset +
      scrollTwist * 2.0;

    const amp =
      (0.16 + 0.24 * Math.sin(t * Math.PI * 0.85)) *
      ampBoost *
      (0.85 + 0.25 * Math.sin(elapsed * 0.9 + ribbon.strandIndex));

    const centerY =
      ribbon.baseY * (1 - t * 0.35) + Math.sin(wavePhase) * amp;
    const centerZ =
      ribbon.baseZ +
      Math.cos(wavePhase * 0.72) * (0.28 * ampBoost) -
      Math.pow(t, 1.4) * 0.55;

    // Twist the ribbon normal smoothly along its travel
    const twist = t * 2.4 + elapsed * 0.55 + ribbon.phaseOffset;
    const dy = Math.cos(twist) * halfWidth;
    const dz = Math.sin(twist) * halfWidth;

    posAttr.setXYZ(i * 2, x, centerY - dy, centerZ - dz);
    posAttr.setXYZ(i * 2 + 1, x, centerY + dy, centerZ + dz);

    const nx = 0.25 * ribbon.side;
    const ny = -Math.sin(twist);
    const nz = Math.cos(twist);
    const nLen = Math.hypot(nx, ny, nz) || 1;
    normAttr.setXYZ(i * 2, nx / nLen, ny / nLen, nz / nLen);
    normAttr.setXYZ(i * 2 + 1, nx / nLen, ny / nLen, nz / nLen);
  }

  posAttr.needsUpdate = true;
  normAttr.needsUpdate = true;
}

interface ArgumentFacetSeed {
  turnId: number;
  speaker: SpeakerId;
  orbitRadius: number;
  baseAngle: number;
  yOffset: number;
  speed: number;
  isDrift: boolean;
  isAttack: boolean;
}

const ARGUMENT_FACET_SEEDS: ArgumentFacetSeed[] = [
  { turnId: 1, speaker: 'A', orbitRadius: 2.35, baseAngle: 0.4, yOffset: 0.85, speed: 0.16, isDrift: false, isAttack: false },
  { turnId: 2, speaker: 'B', orbitRadius: 2.52, baseAngle: 1.35, yOffset: 0.35, speed: -0.14, isDrift: false, isAttack: false },
  { turnId: 3, speaker: 'A', orbitRadius: 2.4, baseAngle: 2.3, yOffset: -0.45, speed: 0.15, isDrift: false, isAttack: false },
  { turnId: 4, speaker: 'B', orbitRadius: 2.62, baseAngle: 3.15, yOffset: -0.82, speed: -0.18, isDrift: false, isAttack: true },
  { turnId: 5, speaker: 'A', orbitRadius: 2.38, baseAngle: 4.1, yOffset: 0.52, speed: 0.14, isDrift: false, isAttack: false },
  { turnId: 6, speaker: 'B', orbitRadius: 2.78, baseAngle: 5.05, yOffset: -0.35, speed: -0.13, isDrift: true, isAttack: false },
  { turnId: 7, speaker: 'A', orbitRadius: 2.86, baseAngle: 5.85, yOffset: 0.68, speed: 0.12, isDrift: true, isAttack: false },
];

interface MicroPearlSeed {
  radius: number;
  speed: number;
  phase: number;
  tiltX: number;
  tiltZ: number;
  yAmp: number;
  scale: number;
}

export function PearlCanvas({
  storyProgressRef,
  postProgressRef,
  sceneStateRef,
  reducedMotion,
  className = '',
}: PearlCanvasProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const pointerRef = useRef({ x: 0, y: 0 });
  const [webglFailed, setWebglFailed] = useState(false);

  useEffect(() => {
    if (!hasWebGLSupport()) {
      setWebglFailed(true);
      return;
    }

    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareWebGL();
    let renderer: THREE.WebGLRenderer;

    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        alpha: true,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglFailed(true);
      return;
    }

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(
      isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2),
    );
    renderer.setClearColor(0x000000, 0);

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;
    renderer.setSize(width, height);
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(35, width / height, 0.1, 60);
    camera.position.set(0, 0, 8.2);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmremGenerator.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmremGenerator.dispose();

    // Rich studio contrast lighting
    const hemiLight = new THREE.HemisphereLight(0xffffff, 0xa88fd4, 0.95);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfffaf6, 2.25);
    keyLight.position.set(4.5, 5.8, 5.4);
    scene.add(keyLight);

    const rimLavender = new THREE.DirectionalLight(0x8f6ac5, 2.8);
    rimLavender.position.set(-5.2, -2.0, -2.6);
    scene.add(rimLavender);

    const rimRose = new THREE.PointLight(0xf3a3c7, 3.0, 16, 1.35);
    rimRose.position.set(3.4, -2.5, 3.0);
    scene.add(rimRose);

    const rimWarm = new THREE.PointLight(0xe8bc9c, 2.0, 14, 1.5);
    rimWarm.position.set(-3.2, 2.8, 2.2);
    scene.add(rimWarm);

    const assemblyGroup = new THREE.Group();
    scene.add(assemblyGroup);

    // 1. Luminous studio halo behind the Argument Pearl
    const auraTex = createSoftGlowTexture(
      'rgba(136, 94, 198, 0.56)',
      'rgba(241, 182, 216, 0.3)',
    );
    const auraGeo = new THREE.PlaneGeometry(8.2, 8.2);
    const auraMat = new THREE.MeshBasicMaterial({
      map: auraTex,
      transparent: true,
      depthWrite: false,
    });
    const auraMesh = new THREE.Mesh(auraGeo, auraMat);
    auraMesh.position.set(0, 0, -2.0);
    assemblyGroup.add(auraMesh);

    // 2. Central Iridescent Pearl Core
    const nacreTex = createPearlNacreTexture();
    nacreTex.anisotropy = renderer.capabilities.getMaxAnisotropy();
    const roughTex = createPearlRoughnessTexture();

    const pearlGeo = new THREE.SphereGeometry(1.42, 84, 84);
    const pearlMat = new THREE.MeshPhysicalMaterial({
      map: nacreTex,
      roughnessMap: roughTex,
      color: new THREE.Color(0xf3e9fc),
      roughness: 0.09,
      metalness: 0.12,
      clearcoat: 1.0,
      clearcoatRoughness: 0.05,
      ior: 1.58,
      iridescence: 1.0,
      iridescenceIOR: 1.46,
      iridescenceThicknessRange: [220, 680],
      sheen: 0.95,
      sheenRoughness: 0.2,
      sheenColor: new THREE.Color(0xdcb0f2),
      envMapIntensity: 1.55,
    });

    pearlMat.onBeforeCompile = (shader) => {
      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <dithering_fragment>',
        `
          vec3 viewDir = normalize(vViewPosition);
          float fresnel = pow(1.0 - clamp(dot(normal, viewDir), 0.0, 1.0), 1.95);
          vec3 iridBand = mix(
            vec3(0.47, 0.33, 0.78),
            vec3(0.95, 0.66, 0.83),
            0.5 + 0.5 * sin(normal.y * 3.2 + normal.x * 2.1)
          );
          gl_FragColor.rgb = mix(gl_FragColor.rgb, iridBand, fresnel * 0.64);
          #include <dithering_fragment>
        `,
      );
    };

    const pearlMesh = new THREE.Mesh(pearlGeo, pearlMat);
    assemblyGroup.add(pearlMesh);

    // Subtle geometric geodesic wireframe aura hugging the pearl (architectural clarity cue)
    const cageGeo = new THREE.IcosahedronGeometry(1.66, 1);
    const cageWireGeo = new THREE.WireframeGeometry(cageGeo);
    const cageMat = new THREE.LineBasicMaterial({
      color: new THREE.Color(0x9b7cd0),
      transparent: true,
      opacity: 0.24,
    });
    const cageLines = new THREE.LineSegments(cageWireGeo, cageMat);
    assemblyGroup.add(cageLines);

    // 3. Precision Gyroscopic Astrolabe Rings (Voice A Lavender, Voice B Champagne, Clarity Ring)
    const ringAGeo = new THREE.TorusGeometry(2.05, 0.022, 20, 140);
    const ringAMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(0x8860c6),
      roughness: 0.22,
      metalness: 0.58,
      transparent: true,
      opacity: 0.84,
    });
    const ringAMesh = new THREE.Mesh(ringAGeo, ringAMat);
    ringAMesh.rotation.set(1.14, 0.42, -0.2);
    assemblyGroup.add(ringAMesh);

    const ringBGeo = new THREE.TorusGeometry(2.38, 0.02, 20, 140);
    const ringBMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(0xdfa579),
      roughness: 0.26,
      metalness: 0.5,
      transparent: true,
      opacity: 0.8,
    });
    const ringBMesh = new THREE.Mesh(ringBGeo, ringBMat);
    ringBMesh.rotation.set(-0.96, -0.45, 0.34);
    assemblyGroup.add(ringBMesh);

    const ringFocusGeo = new THREE.TorusGeometry(2.74, 0.013, 16, 140);
    const ringFocusMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(0xcab6eb),
      roughness: 0.2,
      metalness: 0.72,
      transparent: true,
      opacity: 0.58,
    });
    const ringFocusMesh = new THREE.Mesh(ringFocusGeo, ringFocusMat);
    ringFocusMesh.rotation.set(0.32, 0.15, 0);
    assemblyGroup.add(ringFocusMesh);

    // 4. Dual Living 3D Acoustic Wave Ribbons (Voice A Left, Voice B Right)
    const waveRibbons: WaveRibbonInstance[] = [
      createWaveRibbon(-1, 0, 0xb79ae8, 0xf2e9fc),
      createWaveRibbon(-1, 1, 0x8f6ac5, 0xd9c2f5),
      createWaveRibbon(-1, 2, 0xcab5ee, 0xffffff),
      createWaveRibbon(1, 0, 0xf2ccb0, 0xfff6ef),
      createWaveRibbon(1, 1, 0xe2a57a, 0xf7d2e4),
      createWaveRibbon(1, 2, 0xf0c1d6, 0xffffff),
    ];
    waveRibbons.forEach((wr) => assemblyGroup.add(wr.mesh));

    // 5. 7-Node 3D Argument Constellation (Octahedral Crystal Facets + Filament Graph)
    const facetGeo = new THREE.OctahedronGeometry(0.145, 0);
    const facetMeshes: THREE.Mesh[] = [];
    const facetMats: THREE.MeshPhysicalMaterial[] = [];

    ARGUMENT_FACET_SEEDS.forEach((seed) => {
      const baseColor =
        seed.isAttack
          ? 0xd65b84
          : seed.isDrift
            ? 0xd99b38
            : seed.speaker === 'A'
              ? 0x9b7cd0
              : 0xe6ad84;

      const fMat = new THREE.MeshPhysicalMaterial({
        color: new THREE.Color(baseColor),
        roughness: 0.12,
        metalness: 0.15,
        clearcoat: 1.0,
        iridescence: 0.9,
        transparent: true,
        opacity: 0.94,
      });
      const fMesh = new THREE.Mesh(facetGeo, fMat);
      assemblyGroup.add(fMesh);
      facetMeshes.push(fMesh);
      facetMats.push(fMat);
    });

    // Dynamic filament lines connecting each of the 7 argument facets to the central Pearl
    // and cross-linking rebuttal/support turns (1->2, 2->3, 1->5)
    const EDGE_COUNT = 10;
    const edgePositions = new Float32Array(EDGE_COUNT * 2 * 3);
    const edgeGeo = new THREE.BufferGeometry();
    edgeGeo.setAttribute('position', new THREE.BufferAttribute(edgePositions, 3));
    const edgeMat = new THREE.LineBasicMaterial({
      color: new THREE.Color(0x9b7cd0),
      transparent: true,
      opacity: 0.42,
    });
    const constellationEdges = new THREE.LineSegments(edgeGeo, edgeMat);
    constellationEdges.frustumCulled = false;
    assemblyGroup.add(constellationEdges);

    // 6. InstancedMesh Field of 36 Floating Micro-Pearls
    const MICRO_COUNT = 36;
    const microGeo = new THREE.SphereGeometry(0.068, 18, 18);
    const microMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(0xffffff),
      roughness: 0.14,
      metalness: 0.08,
      clearcoat: 1.0,
      iridescence: 0.95,
      iridescenceIOR: 1.38,
    });
    const microMesh = new THREE.InstancedMesh(microGeo, microMat, MICRO_COUNT);
    microMesh.frustumCulled = false;

    const microSeeds: MicroPearlSeed[] = [];
    const palette = [0xffffff, 0xdfd0f3, 0xa58ac7, 0xf6cfe1, 0xe8bc9c];
    for (let i = 0; i < MICRO_COUNT; i++) {
      const seed: MicroPearlSeed = {
        radius: 2.65 + ((i * 73) % 100) / 34,
        speed: (0.12 + ((i * 29) % 20) / 85) * (i % 2 === 0 ? 1 : -1),
        phase: (i / MICRO_COUNT) * Math.PI * 2,
        tiltX: (((i * 41) % 100) / 100 - 0.5) * 1.4,
        tiltZ: (((i * 67) % 100) / 100 - 0.5) * 1.2,
        yAmp: 0.35 + ((i * 19) % 10) * 0.08,
        scale: 0.55 + ((i * 31) % 10) * 0.08,
      };
      microSeeds.push(seed);
      _tmpColor.setHex(palette[i % palette.length]);
      microMesh.setColorAt(i, _tmpColor);
    }
    if (microMesh.instanceColor) microMesh.instanceColor.needsUpdate = true;
    assemblyGroup.add(microMesh);

    // 7. Soft contact shadow anchor
    const shadowTex = createSoftGlowTexture(
      'rgba(128, 92, 184, 0.28)',
      'rgba(143, 106, 197, 0.08)',
    );
    const shadowGeo = new THREE.PlaneGeometry(5.6, 5.6);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
    });
    const shadowPlane = new THREE.Mesh(shadowGeo, shadowMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.set(0, -2.55, 0);
    assemblyGroup.add(shadowPlane);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const onPointerMove = (e: PointerEvent) => {
      const nx = (e.clientX / window.innerWidth) * 2 - 1;
      const ny = -(e.clientY / window.innerHeight) * 2 + 1;
      pointerRef.current.x = THREE.MathUtils.clamp(nx, -1, 1);
      pointerRef.current.y = THREE.MathUtils.clamp(ny, -1, 1);
    };
    window.addEventListener('pointermove', onPointerMove, { passive: true });

    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      renderer.setPixelRatio(
        isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2),
      );
    };
    window.addEventListener('resize', onResize);

    let frameId = 0;
    let disposed = false;
    const clock = new THREE.Clock();

    function updateSceneForFrame(dt: number, elapsed: number) {
      const p = THREE.MathUtils.clamp(storyProgressRef.current, 0, 1);
      const post = THREE.MathUtils.clamp(postProgressRef.current, 0, 1);
      const state = sceneStateRef.current;
      const isDesktop = window.innerWidth >= 1024;

      const fly = easeCubic(seg(p, 0.06, 0.44));
      const settle = easeCubic(seg(p, 0.44, 0.78));
      const postEase = easeCubic(seg(post, 0.0, 0.14));

      // Story camera choreography
      const storyX = isDesktop ? THREE.MathUtils.lerp(0.0, 0.18, settle) : 0;
      const storyY = isDesktop ? -0.18 + fly * 0.26 - settle * 0.2 : -0.1;
      const storyScale = 1.02 + fly * 0.52 - settle * 0.44;
      const storyCamZ = 8.2 - fly * 3.3 + settle * 2.3;

      // Post-scroll choreography: prominent kinetic presence across Example, How it works, FAQ & Footer
      const endCenterFactor = seg(post, 0.85, 1.0);
      const ambientSweepX = isDesktop
        ? Math.sin(post * Math.PI * 2.2) * 1.9 * (1 - endCenterFactor)
        : 0;
      const ambientSweepY =
        Math.cos(post * Math.PI * 1.8) * 0.28 * (1 - endCenterFactor);
      const ambientScale = THREE.MathUtils.lerp(1.18, 1.32, endCenterFactor);
      const ambientCamZ = THREE.MathUtils.lerp(6.8, 6.25, endCenterFactor);

      const targetX = THREE.MathUtils.lerp(storyX, ambientSweepX, postEase);
      const targetY = THREE.MathUtils.lerp(storyY, ambientSweepY, postEase);
      const targetScale = THREE.MathUtils.lerp(storyScale, ambientScale, postEase);
      const targetCamZ = THREE.MathUtils.lerp(storyCamZ, ambientCamZ, postEase);

      const floatY = reducedMotion ? 0 : Math.sin(elapsed * 0.85) * 0.07;
      _targetGroupPos.set(
        targetX - pointerRef.current.x * (reducedMotion ? 0 : 0.18),
        targetY + floatY - pointerRef.current.y * (reducedMotion ? 0 : 0.14),
        0,
      );

      const dampFactor = reducedMotion ? 1 : 5.0;
      assemblyGroup.position.x = THREE.MathUtils.damp(
        assemblyGroup.position.x,
        _targetGroupPos.x,
        dampFactor,
        dt,
      );
      assemblyGroup.position.y = THREE.MathUtils.damp(
        assemblyGroup.position.y,
        _targetGroupPos.y,
        dampFactor,
        dt,
      );
      const nextScale = THREE.MathUtils.damp(
        assemblyGroup.scale.x,
        targetScale,
        dampFactor,
        dt,
      );
      assemblyGroup.scale.setScalar(nextScale);

      const camOrbitX =
        Math.sin(p * Math.PI * 1.15) * 0.65 * (1 - postEase) +
        Math.sin(post * Math.PI * 1.5) * 0.32 * postEase;
      _targetCamPos.set(
        camOrbitX + pointerRef.current.x * (reducedMotion ? 0 : 0.34),
        pointerRef.current.y * (reducedMotion ? 0 : 0.22),
        targetCamZ,
      );
      camera.position.x = THREE.MathUtils.damp(
        camera.position.x,
        _targetCamPos.x,
        4.0,
        dt,
      );
      camera.position.y = THREE.MathUtils.damp(
        camera.position.y,
        _targetCamPos.y,
        4.0,
        dt,
      );
      camera.position.z = THREE.MathUtils.damp(
        camera.position.z,
        _targetCamPos.z,
        4.0,
        dt,
      );

      _lookTarget.set(assemblyGroup.position.x * 0.22, targetY * 0.3, 0);
      camera.lookAt(_lookTarget);

      const totalScroll = p + post * 1.5;

      // Sync focus ring color & pulse with active inspection mode
      const isAttackMode = state.activeMode === 'attack' && post > 0.05;
      const isDriftMode = state.activeMode === 'drift' && post > 0.05;
      const targetRingColor = isAttackMode
        ? 0xd65b84
        : isDriftMode
          ? 0xd99b38
          : 0xcab6eb;
      _tmpColor.setHex(targetRingColor);
      ringFocusMat.color.lerp(_tmpColor, 0.08);

      // Update kinetic Dual Voice Wave Ribbons
      const speakerABoost =
        state.activeSpeaker === 'A'
          ? 1.45
          : state.activeMode === 'speaking-time'
            ? 1.28
            : 1.0;
      const speakerBBoost =
        state.activeSpeaker === 'B'
          ? 1.45
          : state.activeMode === 'speaking-time'
            ? 0.92
            : 1.0;

      const waveSpan = isDesktop ? 1.0 : 0.72;
      const waveElapsed = reducedMotion ? 0 : elapsed;

      waveRibbons.forEach((wr) => {
        const boost = wr.side === -1 ? speakerABoost : speakerBBoost;
        updateWaveRibbon(wr, waveElapsed, boost, waveSpan, totalScroll);
      });

      // Update 7-Node Argument Constellation & Filament Graph
      const edgeAttr = edgeGeo.getAttribute('position') as THREE.BufferAttribute;
      ARGUMENT_FACET_SEEDS.forEach((seed, idx) => {
        const angle =
          seed.baseAngle +
          (reducedMotion ? 0 : elapsed * seed.speed) +
          totalScroll * 1.4;

        // In Drift mode (or for turns 6 & 7), drift nodes visibly swing further off-axis
        const driftOffset =
          seed.isDrift && (isDriftMode || state.activeTurnId === seed.turnId)
            ? 0.72
            : seed.isDrift
              ? 0.22
              : 0;

        const r = (seed.orbitRadius + driftOffset + fly * 0.45) * (isDesktop ? 1 : 0.78);
        const fx = Math.cos(angle) * r;
        const fz = Math.sin(angle) * r * 0.85;
        const fy =
          seed.yOffset +
          (reducedMotion ? 0 : Math.sin(elapsed * 1.2 + idx) * 0.14) +
          (seed.isDrift && isDriftMode ? 0.4 : 0);

        const fMesh = facetMeshes[idx];
        fMesh.position.set(fx, fy, fz);

        const isFocusedTurn = state.activeTurnId === seed.turnId;
        const targetFacetScale = isFocusedTurn ? 1.65 : 1.0;
        const curS = THREE.MathUtils.lerp(fMesh.scale.x, targetFacetScale, 0.12);
        fMesh.scale.setScalar(curS);
        if (!reducedMotion) {
          fMesh.rotation.y = elapsed * 0.9 + idx;
          fMesh.rotation.x = elapsed * 0.5 + idx;
        }

        // Edge idx: connect node to central Pearl core
        edgeAttr.setXYZ(idx * 2, 0, 0, 0);
        edgeAttr.setXYZ(idx * 2 + 1, fx, fy, fz);
      });

      // Cross-link argumentative edges: Turn 2 -> Turn 1, Turn 3 -> Turn 2, Turn 5 -> Turn 1
      const links: [number, number][] = [
        [1, 0],
        [2, 1],
        [4, 0],
      ];
      links.forEach(([fromIdx, toIdx], lIdx) => {
        const baseEdge = 7 + lIdx;
        const pFrom = facetMeshes[fromIdx].position;
        const pTo = facetMeshes[toIdx].position;
        edgeAttr.setXYZ(baseEdge * 2, pFrom.x, pFrom.y, pFrom.z);
        edgeAttr.setXYZ(baseEdge * 2 + 1, pTo.x, pTo.y, pTo.z);
      });
      edgeAttr.needsUpdate = true;

      edgeMat.opacity = state.activeMode === 'argument-trail' ? 0.72 : 0.38;

      // Update orbiting InstancedMesh micro-pearls
      for (let i = 0; i < MICRO_COUNT; i++) {
        const s = microSeeds[i];
        const angle =
          s.phase + (reducedMotion ? 0 : elapsed * s.speed) + totalScroll * 1.6;
        const r = (s.radius + fly * 0.65 * (1 - postEase * 0.4)) * (isDesktop ? 1 : 0.78);
        const x = Math.cos(angle) * r;
        const z = Math.sin(angle) * r;
        const y =
          Math.sin(angle * 1.5 + s.tiltX) * s.yAmp +
          Math.cos(angle) * s.tiltZ * 0.4;

        _dummy.position.set(x, y, z);
        _dummy.scale.setScalar(s.scale * (1 + fly * 0.18));
        _dummy.updateMatrix();
        microMesh.setMatrixAt(i, _dummy.matrix);
      }
      microMesh.instanceMatrix.needsUpdate = true;

      if (!reducedMotion) {
        pearlMesh.rotation.y = elapsed * 0.24 + totalScroll * 2.8;
        pearlMesh.rotation.x = Math.sin(elapsed * 0.32) * 0.14;
        cageLines.rotation.y = -elapsed * 0.12 - totalScroll * 0.9;
        cageLines.rotation.z = elapsed * 0.08;
        ringAMesh.rotation.z = -0.2 + elapsed * 0.28 + totalScroll * 1.3;
        ringBMesh.rotation.z = 0.34 - elapsed * 0.22 - totalScroll * 1.1;
        ringFocusMesh.rotation.x = 0.32 + Math.sin(elapsed * 0.4) * 0.18;
        ringFocusMesh.rotation.y = 0.15 + elapsed * 0.18 + totalScroll * 0.8;
        auraMesh.lookAt(camera.position);
      }
    }

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl || typeof gl.fenceSync !== 'function') {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.05);
      const elapsed = clock.getElapsedTime();
      updateSceneForFrame(dt, elapsed);
      renderer.render(scene, camera);
      if (reducedMotion) return;
      if (isSoftwareGl) afterDraw(tick);
      else frameId = requestAnimationFrame(tick);
    }

    if (reducedMotion) {
      updateSceneForFrame(0.016, 0);
      renderer.render(scene, camera);
    } else {
      tick();
    }

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('resize', onResize);

      pearlGeo.dispose();
      pearlMat.dispose();
      nacreTex.dispose();
      roughTex.dispose();
      cageGeo.dispose();
      cageWireGeo.dispose();
      cageMat.dispose();
      auraGeo.dispose();
      auraMat.dispose();
      auraTex.dispose();
      ringAGeo.dispose();
      ringAMat.dispose();
      ringBGeo.dispose();
      ringBMat.dispose();
      ringFocusGeo.dispose();
      ringFocusMat.dispose();
      waveRibbons.forEach((wr) => {
        wr.geo.dispose();
        wr.mat.dispose();
      });
      facetGeo.dispose();
      facetMats.forEach((m) => m.dispose());
      edgeGeo.dispose();
      edgeMat.dispose();
      microGeo.dispose();
      microMat.dispose();
      shadowGeo.dispose();
      shadowMat.dispose();
      shadowTex.dispose();
      envTarget.dispose();
      renderer.dispose();

      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [reducedMotion, storyProgressRef, postProgressRef, sceneStateRef]);

  if (webglFailed) {
    return (
      <div
        className={`pointer-events-none flex items-center justify-center ${className}`}
        aria-hidden="true"
      >
        <div className="pearl-fallback h-72 w-72 rounded-full sm:h-96 sm:w-96" />
      </div>
    );
  }

  return (
    <div
      ref={mountRef}
      className={`pointer-events-none ${className}`}
      aria-hidden="true"
    />
  );
}
