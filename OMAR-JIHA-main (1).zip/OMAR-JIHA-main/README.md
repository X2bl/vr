# Where’s your argument? — Landing Page

Introductory and interactive exploration page for **Where’s your argument?**, a calm debate moderation workspace for two-person English debates.

## Running Locally

```bash
npm install
npm run dev
```

## Configuring `APP_URL`

All **Open workspace** links read from a single configuration module (`src/config.ts`).

To point the buttons to a deployed workspace instance, set `VITE_APP_URL` before building or running:

```bash
VITE_APP_URL="https://your-workspace-domain.example/" npm run build
```

When `VITE_APP_URL` is not set, `APP_URL` defaults to `http://127.0.0.1:7863/`.

## Production Build

```bash
npm run build
```
